'''
TODO @leosanchezsoler
'''
#import the necessary libraries

import pandas as pd
import numpy as np 

#pip3 install seaborn
#pip3 install plotly
#pip3 install psutil

import matplotlib.pylot as plt
import seaborn as sns

import plotly.io as pio
from plotly.offline import init_notebook_mode, iplot, plot
import plotly.express as px
from plotly.graph_objs import Scatter, Box
import plotly.graph_objects as go 


class Plot():
    '''
                        --what it does--
    this class gets a DataFrame as an instance and, depending on its subclasses,
    it will draw a specific chart.
    '''
    def __init__(self, df, columns:list):
        '''
        Initialize the class
        df: pandas.DataFrame that will be plotted
        columns: the list of columns that will be plotted
        '''
        self.df = df
        self.columns = columns

    def save_file(self, save=False: bool, file_ext:str):
        '''
        this method saves the file in both .png and .html
        save: a bool that is False by default. Change to True in order to save the file
        file_ext: a string that must contain the extension in which the plot will be saved
        '''
        



class Scatterplot(Plot):
    def __init__(self)
(self, columns, x_axis, y_axis, file_ext):
        """
        Draws a scatterplot
        columns: a list of the items that will be drawn
        x_axis: a string with the item that wants to be represented on the x_axis
        y_axis: a string with the item that wants to be represented on the y_axis
        file_ext: the name of the extension that wants to be saved (html, png). Depending on the extension, it will be saved differently
        """
        self.columns = columns
        self.x_axis = x_axis
        self.y_axis = y_axis
        self.file_ext = file_ext
        pass

class Boxplot(Plot):
    def __init__(self)
    '''
    Draws a boxplot
    '''
    pass
class Lineplot(Plot):
    '''
    Draws a lineplot for showing tendencies
    '''
    pass

class Piechart(Plot):
    '''
    Draws a piechart to show specific values for categorical items
    '''
    pass

